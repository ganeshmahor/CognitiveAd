package src.main.test;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import src.main.bean.Person;
import src.main.service.PersonService;

public class AppMain {

	/*@Autowired
	PersonService personService;*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		PersonService personService = (PersonService)ctx.getBean("personService");
		
		Person p = new Person(6,"Jai","Narayana",13);
		Person p1 = new Person(7,"Jai","Madhusudhana",14);
	
		personService.addPerson(p);
		personService.addPerson(p1);
		
		List<Person> persons = personService.findAll();
		for(Person per : persons)
		{
			System.out.println(per);
		}
		
		personService.deletePerson(5);
		for(Person per : persons)
		{
			System.out.println(per);
		}
		
		p.setFirstName("Jai");
		p.setLastName("Srimannar");
		p.setAge(13);
		personService.editPerson(p,4);
		for(Person per : persons)
		{
			System.out.println(per);
		}
		
		
		ctx.close();
	}

}
