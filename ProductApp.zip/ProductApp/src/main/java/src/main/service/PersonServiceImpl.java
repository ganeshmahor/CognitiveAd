package src.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.main.bean.Person;
import src.main.dao.PersonDao;
import src.main.dao.PersonDaoImpl;

//@Service("personService")
public class PersonServiceImpl implements PersonService {

	@Autowired
	PersonDaoImpl personDao;
	
	public void addPerson(Person person) {
		// TODO Auto-generated method stub
		personDao.addPerson(person);
		
	}

	public void editPerson(Person person, int personId) {
		// TODO Auto-generated method stub
		personDao.editPerson(person, personId);
	}

	public void deletePerson(int personId) {
		// TODO Auto-generated method stub
		personDao.deletePerson(personId);
	}

	public Person find(int personId) {
		// TODO Auto-generated method stub
		return personDao.find(personId);
	}

	public List<Person> findAll() {
		// TODO Auto-generated method stub
		return personDao.findAll();
	}
	

}
