package com.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

	@RequestMapping(value="/welcome",method=RequestMethod.GET)
    @ResponseBody
	public String welcomeMessage() {
	
    	return "Welcometo Spring";
}	
	
	@RequestMapping(value="/welcome1",method=RequestMethod.GET)
    @ResponseBody
	public String welcomeMessage1() {
	
    	return "Welcometo SpringMVC";
}	
}
